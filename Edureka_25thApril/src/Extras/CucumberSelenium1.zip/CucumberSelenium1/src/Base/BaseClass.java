package Base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BaseClass {

	public static WebDriver driver;
	
	public static void startBrowser(String browserName) {
		
		try {
			if(browserName.equalsIgnoreCase("Chrome")) 
			{
				System.setProperty("webdriver.chrome.driver",
						".\\lib\\chromedriver.exe");
				driver = new ChromeDriver();
			}
			else if(browserName.equalsIgnoreCase("Firefox")) 
			{
				System.setProperty("webdriver.gecko.driver",
						".\\lib\\geckodriver.exe");
				driver = new FirefoxDriver();
			}
			else if(browserName.equalsIgnoreCase("ie")) 
			{
				System.setProperty("webdriver.ie.driver",
						".\\lib\\IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			}
			
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		} catch (WebDriverException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void openUrl() {
		driver.get("http://newtours.demoaut.com/");
	}
	
	public static void click(By loc) {
		driver.findElement(loc).click();
	}
	
	public static void enterText(By loc, String data) {
		driver.findElement(loc).clear();
		driver.findElement(loc).sendKeys(data);
	}
	
	public void displayOfElement(By loc) {
		try {
			driver.findElement(loc).isDisplayed();
		} catch (Exception e) {
			driver.quit();
		}
	}
}
