package runnerTests;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "features",
		glue = "src/stepDefinitions/loginStepDefn",
		plugin = {"pretty", "html:reports/cucumber-reports"},
		monochrome = true
		)
public class Runner {

}
