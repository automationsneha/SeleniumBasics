package stepDefinitions;

import Base.BaseClass;
import ObjectRepository.HomePage_OR;
import ObjectRepository.LoggedIn_OR;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class loginStepDefn extends BaseClass{

	HomePage_OR homePage_OR = new HomePage_OR(); 
	LoggedIn_OR loggedIn_OR = new LoggedIn_OR();
	
	
	@Given("^User is on HomePage$")
	public void user_is_on_HomePage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		startBrowser("Chrome");
		openUrl();
		System.out.println("The User is on HomePage");
	}

	@When("^User enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   enterText(homePage_OR.username, "tutorial");
	   enterText(homePage_OR.password, "tutorial");
	}

	@And("^clicks on Signin$")
	public void clicks_on_Signin() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   click(homePage_OR.signin);
	}

	@Then("^User should be able to see the Sign-off$")
	public void user_should_be_able_to_see_the_Sign_off() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(5000);
		displayOfElement(loggedIn_OR.logout);
	}
	
	
}
