package ObjectRepository;

import org.openqa.selenium.By;

public class HomePage_OR {

	public By username = By.name("userName");
	public By password = By.name("password");
	public By signin = By.name("login");
	
}
