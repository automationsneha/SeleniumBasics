package ObjectRepository;

import org.openqa.selenium.By;

public class LoggedIn_OR {

	public By logout = By.linkText("SIGN-OFF");
	
}
