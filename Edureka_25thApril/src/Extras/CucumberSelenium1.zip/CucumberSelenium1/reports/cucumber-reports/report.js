$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("login.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Abhresh"
    }
  ],
  "line": 3,
  "name": "Login Feature",
  "description": "Verify if user is able to login",
  "id": "login-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@login"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "Login as Authenticated User",
  "description": "",
  "id": "login-feature;login-as-authenticated-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@Validinput"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "User is on HomePage",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "User enters username and password",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "clicks on Signin",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User should be able to see the Sign-off",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});